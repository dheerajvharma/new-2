<!DOCTYPE html>
<html class="no-js" lang="en">
<head>
<meta charset="utf-8" />
<title>About Us - Khalsa Computerised Chaabi Wala</title>
<meta name="description" content=""/>
<meta name="robots" content="INDEX, Follow" />
<meta name="language" content="en-us" />
<meta name="revisit-after" content="2 days"/>
<link rel="canonical" href=""/>   
<?php include("inc/header.php"); ?>
<?php include("inc/menu.php"); ?>
<!--=====================================-->
    <div class="breadcrumb-wrap breadcrumb-wrap-2">
            <div class="container">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">About Us</li>
                    </ol>
                </nav>
            </div>
        </div>

<!--=====================================-->
    <section class="about-wrap2" style="background-color: white;">
            <div class="container">
                <div class="row flex-row-reverse flex-lg-row">
                    <div class="col-xl-6 col-lg-6">
                        <div class="about-img">
                            <img src="img/about-1.jpg" alt="about" width="846" height="687">
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-6">
                        <div class="about-box3 wow fadeInUp" data-wow-delay=".2s">
                            <span class="item-subtitle">About Us</span>
                            <h2 class="item-title">We're on a Mission to Change  View of RealEstate Field.</h2>
                            <p>when an unknown printer took a galley of type and scrambled it to make 
                                type specimen bookt has survived not only five centuries alsoey jequery 
                                the leap into electronic typesetting.
                            </p>
                            <div class="row">
                                <div class="col-lg-6 col-md-6 col-sm-6">
                                    <div class="about-layout1">
                                        <div class="item-img">
                                            <img src="img/shape14.svg" alt="shape" width="60" height="57">
                                        </div>
                                        <h3 class="item-sm-title">Modern Villa</h3>
                                        <p>when unknown printer took galley 
                                            of type and scrambled.
                                        </p>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-6">
                                    <div class="about-layout1">
                                        <div class="item-img">
                                            <img src="img/shape15.svg" alt="shape" width="62" height="57">
                                        </div>
                                        <h3 class="item-sm-title">Secure Payment</h3>
                                        <p>when unknown printer took galley 
                                            of type and scrambled.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                   
                </div>
                
            </div>
        </section>
 <!--=====================================-->
    <section class="brand-wrap1" style="background-color: #f5f5f5;">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-7 col-12 ">
				     	<div class="about-box2  wow fadeInRight" data-wow-delay=".5s">
                      <div class="item-heading-left mb-bottom">
                           <span class="section-subtitle" style="color:#000; font-size:22px; font-weight:400;"></span> 
                        </div><br>
                            <h4>Shree Ran Properties & Construction</h4><br>
                            <p style="color:#666; font-size:16px; font-weight:400;">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Tempore totam, illum error provident, nemo odit molestiae facere omnis doloribus optio et praesentium esse nulla? Tenetur at magni, est, eius a aliquid, voluptatibus quaerat ipsum odit optio commodi? Minus rerum eveniet harum fugit perferendis illum adipisci ratione. Ipsum quaerat temporibus molestias. Lorem, ipsum dolor sit amet consectetur adipisicing elit. Tempora odit illum excepturi ipsum cupiditate velit, deserunt assumenda eaque doloremque quia molestiae suscipit iste ut! Perferendis Lorem ipsum dolor sit, amet consectetur adipisicing elit. Magni fugit distinctio nisi iure, illum velit quis.</p>
                        </div>
                      </div> 
					     <div class="col-xl-5 col-lg-6" id="aaaaa">
                            <img src="img/img-7.jpg" alt="" style="border: 2px dashed #b4b7bb; padding: 13px; border-radius: 10px;"> 
                      </div>
                 </div>
             </div><br>   
         </section>    
<!--=====================================-->
<?php include("inc/footer.php"); ?>
</body>
</html>


