<!DOCTYPE html>
<html class="no-js" lang="en">
  <head>
    <meta charset="utf-8" />
    <title>Shree Ran Properties & Construction</title>
    <meta name="description" content="" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="shortcut icon" type="image/x-icon" href="img/favicon-homlisti.svg" />
    <link rel="stylesheet" href="css/jquery-ui.css" />
    <link rel="stylesheet" href="css/bootstrap.min.css" />
    <link rel="stylesheet" href="css/animate.min.css" />
    <link rel="stylesheet" href="vendor/owlcarousel/owl.carousel.min.css" />
    <link rel="stylesheet" href="vendor/owlcarousel/owl.theme.default.min.css" />
    <link rel="stylesheet" href="css/swiper-bundle.min.css" />
    <link rel="stylesheet" href="css/flaticon/font/flaticon.css" />
    <link rel="stylesheet" href="css/nice-select.css" />
    <link rel="stylesheet" href="css/animate.min.css" /> 
    <link rel="stylesheet" href="css/magnific-popup.css" />
    <link rel="stylesheet" href="css/all.min.css" />
    <link rel="stylesheet" href="css/pannellum.css" />
    <link rel="stylesheet" href="vendor/noUiSlider/nouislider.min.css" />
    <link rel="stylesheet" href="style.css" />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&family=Ubuntu:wght@400;500;700&display=swap" rel="stylesheet"/>
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Ubuntu:wght@400;500;700&display=swap" rel="stylesheet" />
  </head>
  <body class="sticky-header">
<?php include("inc/menu.php"); ?>
<!--=====================================-->
        <section class="about-wrap2 offdark-bg"> <br><br><br>
            <div class="container">
                <div class="item-heading-center">
            <h2 class="section-title">Thnak You!</h2>
              <P style="color:#000; font-size:14px; font-weight:200;">You request has been submitted successfully.<br>Our representative will coordinate with you shortly.</P>
          </div>   
            </div><br><br><br>
        </section>
<!--=====================================-->
	  <?php include("inc/footer.php"); ?>
  </body>
</html>
