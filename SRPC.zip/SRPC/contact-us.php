<!DOCTYPE html>
<html class="no-js" lang="en">
<head>
<meta charset="utf-8"/>
<title>Contact Us - Shree Ran Properties & Construction</title>
<meta name="description" content=""/>
<meta name="robots" content="INDEX, Follow" />
<meta name="language" content="en-us" />
<meta name="revisit-after" content="2 days"/>
<link rel="canonical" href="" /> 
<?php include("inc/header.php");?>
<?php include("inc/menu.php"); ?>
<!--=====================================-->
         <div class="breadcrumb-wrap">
            <div class="container">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                       <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                       <li class="breadcrumb-item active" aria-current="page">Contact Us</li>
                    </ol>
                </nav>
            </div>
        </div>
<!--=====================================-->
       <section class="agent-wrap2">
            <div class="container">
                <div class="row gutters-40">
                    <div class="col-lg-8">
                        <div class="team-box1 team-box5">
                            <div class="item-content">
                                <div class="item-title">
                                    <div class="item-details">
                                        <h2 class="item-subtitle">Shree Ram Properties & Construction</h2>
                                    </div>
                                </div>
                                <p>All Kind Of Properties & Civil Works</p>
                                <div class="item-contact-2">
                                  <div class="item-icon"><i class="fas fa-map-marker-alt"></i>Add :
                                        <span>Shop No. B 14 Main Market Sector-1 IMT Manesar, Gurugram (Hr.) 122052</span></div>
                                    <div class="item-icon"><i class="far fa-envelope"></i>E-mail :
                                        <span>sSheerampropertiesconstruction@gmail.com</span></div>
                                    <div class="item-phn-no"><i class="fas fa-phone-alt"></i>Call: <span>+91
                                         9896 7070 22</span></div>
                                    <div class="item-phn-no"><i class="fas fa-phone-alt"></i>Call: <span>+91
                                         9896 7070 44</span></div>        
                                </div>
                            </div>
                        </div>
                    </div>
                       <div class="col-lg-4 widget-break-lg sidebar-widget">
                          <?php include("inc/form.php"); ?> 
                    </div>
                </div>
            </div>
        </section>
<!--=====================================-->
	  <?php include("inc/footer.php"); ?>
  </body>
</html>
