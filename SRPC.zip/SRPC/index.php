<!DOCTYPE html>
<html class="no-js" lang="en">
<head>
<meta charset="utf-8"/>
<title>Shree Ran Properties & Construction - Home</title>
<meta name="description" content=""/>
<meta name="robots" content="INDEX, Follow" />
<meta name="language" content="en-us"/>
<meta name="revisit-after" content="2 days"/>
<link rel="canonical" href="" />   
<?php include("inc/header.php"); ?>
<?php include("inc/menu.php"); ?>
<!--=====================================-->
         <section class="main-banner-wrap1" data-bg-image="img/banner-1.jpg">
            <div class="container">
                <div class="row">
                    <!-- <div class="col-lg-8">
                        <div class="main-banner-box2 wow slideInUp" data-wow-delay=".3s">
                            <div class="item-img">
                                <img src="img/img-1.jpeg" alt="banner" width="350" >
                            </div>
                        </div>
                    </div> -->
                      <div class="col-lg-4">
                    <br>
                        <div class="main-banner-box4 wow slideInUp" data-wow-delay=".3s">
                            <div class="banner-style-1">
                                <div class="item-category-box1">
                                    <div class="item-category">Buy Sall Rent</div>
                                </div>
                                <div class="item-price">$99,000/<span>mo</span></div>
                            </div>
                            <h3 class="item-title">Shree Ran Properties & Construction</h3>
                            <div class="location-area"><i class="flaticon-maps-and-flags"></i>Sector-1,  Gurugram</div>
                            <div class="item-categoery3 item-categoery4">
                                <ul>
                                    <li><i class="flaticon-bed"></i>Beds: 99</li>
                                    <li><i class="flaticon-shower"></i>Baths: 99</li>
                                    <li><i class="flaticon-two-overlapping-square"></i>99 Sqft</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    <!--=====================================-->
         <section class="feature-rent-wrap1" style="background-color: white;">
            <div class="container">
                <div class="row">
                    <div class="col-xl-8 col-lg-7">
                        <div class="rent-box1 wow fadeInUp" data-wow-delay=".2s">
                           <div class="item-content">
                             <h3 class="item-title"><a href="single-listing1.html">Shree Ran Properties & Construction</a></h3>                  
                                <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Repellat, minus. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Qui quam nobis aperiam facilis fugit autem delectus consectetur, in perspiciatis. Massa tempor nec feugiat nisl pretium. Egestas fringilla phasellus faucibus scelerisque eleifend donec. Porta nibh venenatis cras sed felis eget velit aliquet. Neque volutpat ac tincidunt vitae semper quis lectus.</p>
                            </div><br>
                        <div class="row">
                          <div class="col-lg-6 col-md-6 col-sm-6">
                            <div class="team-box1 team-box2 wow fadeInUp" data-wow-delay=".6s">
                              <div>
                                <a href="#">
                                    <img src="img/img-2.png" >
                                 </a>                                          
                             </div>
                          </div><br>
                        </div>
                           <div class="col-lg-6 col-md-6 col-sm-6">
                            <div class="team-box1 team-box2 wow fadeInUp" data-wow-delay=".6s">
                              <div>
                                <a href="#">
                                    <img src="img/img-3.png" >
                                </a>                                       
                            </div>
                          </div>
                        </div>
                      </div>
                   </div>
                 </div>
                    <div class="col-xl-4 col-lg-5 wow fadeInUp" data-wow-delay=".4s">                
                        <?php include("inc/form.php"); ?>
                    </div>
                </div>
            </div>
        </section>  
<!--=====================================-->
<!--=====================================-->
<section class="progress-bar-wrap1 counter-appear">
            <!-- <div class="shape-img1 wow fadeInLeft" data-wow-delay=".4s">
                <img src="img/figure/counter-bg-2.png" alt="progress">
            </div> -->
            <div class="container">
                <div class="item-heading-bar">
                    <h2 class="item-title">Real Estate by the Numbers</h2>
                    <p>In 2023 things look like this percentage</p>
                </div>
                <div class="row">
                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="progress-box1 wow zoomIn" data-wow-delay=".2s">
                            <div class="progress-layout">
                                <div class="process-circle"></div>
                                <div class="process-circle"></div>
                                <div class="process-circle"></div>
                                <div class="progress-content">
                                    <div class="item-parcent"><span class="counterUp" data-counter="80">80</span>%</div>
                                    <label>Completed Property</label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="progress-box1 wow zoomIn" data-wow-delay=".3s">
                            <div class="progress-layout">
                                <div class="process-circle"></div>
                                <div class="process-circle"></div>
                                <div class="process-circle"></div>
                                <div class="progress-content">
                                    <div class="item-parcent"><span class="counterUp" data-counter="27">27</span>%</div>
                                    <label>Property Taxes</label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="progress-box1 wow zoomIn" data-wow-delay=".4s">
                            <div class="progress-layout">
                                <div class="process-circle"></div>
                                <div class="process-circle"></div>
                                <div class="process-circle"></div>
                                <div class="progress-content">
                                    <div class="item-parcent"><span class="counterUp" data-counter="99">99</span>%</div>
                                    <label>Satisfied Customer</label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="progress-box1 wow zoomIn" data-wow-delay=".2s">
                            <div class="progress-layout">
                                <div class="process-circle"></div>
                                <div class="process-circle"></div>
                                <div class="process-circle"></div>
                                <div class="progress-content">
                                    <div class="item-parcent"><span class="counterUp" data-counter="55">55</span>%</div>
                                    <label>Home Ownership</label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    <!--=====================================-->
<section class="feature-wrap1" style="background-color: #e5f2ff;">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-xl-6 col-lg-6">
                        <div class="feature-box1 wow fadeInLeft" data-wow-delay=".2s">
                        <div class="item-categoery">
                                <a href="#">Buy Sall Rent</a>
                            </div>
                            <div class="heading-title">
                                
                                <h2>Shree Ran Properties & Construction</h2>
                            </div>
                              <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Architecto, soluta ipsa vel, eveniet fuga nulla accusantium explicabo excepturi blanditiis et nobis ex quas iste reprehenderit ratione iure dolores, dolore aperiam recusandae at aspernatur. Ut repudiandae quae deserunt cum optio suscipit, reprehenderit laboriosam excepturi nesciunt</p>
                            <div class="price-area-style-1">
                                <div class="details-button">
                                    <a href="contact-us.php" class="item-btn">Contact Us</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-6">
                        <div class="featured-thumb-slider-area">
                            <div class="inner-box-1">
                                <div class="feature-box2 swiper-container wow fadeInRight" data-wow-delay=".3s">
                                    <div class="swiper-wrapper">
                                        <div class="swiper-slide">
                                            <div class="feature-img1">
                                                <img src="img/img-4.jpg" alt="" >
                                            </div>
                                        </div>
                                        <div class="swiper-slide">
                                            <div class="feature-img1">
                                                <img src="img/img-5.jpg" alt="">
                                            </div>
                                        </div>
    
                                        <div class="swiper-slide">
                                            <div class="feature-img1">
                                                <img src="img/img-6.jpg" alt="">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="inner-box-2">
                                    <div class="featured-thum-slider swiper-container">
                                        <div class="swiper-wrapper">
                                            <div class="swiper-slide">
                                                <div class="item-img">
                                                    <img src="img/img-4.jpg" alt="" >
                                                </div>
                                            </div>
                                            <div class="swiper-slide">
                                                <div class="item-img">
                                                    <img src="img/img-5.jpg" alt="" >
                                                </div>
                                            </div>
                                            <div class="swiper-slide">
                                                <div class="item-img">
                                                    <img src="img/img-6.jpg" alt="">
                                                </div>
                                            </div>    
                                        </div>
                                    </div>
    
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
<!--=====================================-->

<?php include("inc/footer.php"); ?>
</body>
</html>


