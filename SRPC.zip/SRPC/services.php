<!DOCTYPE html>
<html class="no-js" lang="en">
<head>
<meta charset="utf-8"/>
<title>Shree Ran Properties & Construction - Buy Sall Rent</title>
<meta name="description" content=""/>
<meta name="robots" content="INDEX, Follow" />
<meta name="language" content="en-us"/>
<meta name="revisit-after" content="2 days"/>
<link rel="canonical" href="" />   
<?php include("inc/header.php"); ?>
<?php include("inc/menu.php"); ?>
<!--=====================================-->  
      <section class="feature-wrap1" style="background-color: #e5f2ff;">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-xl-6 col-lg-6">
                        <div class="feature-box1 wow fadeInLeft" data-wow-delay=".2s">
                        <div class="item-categoery">
                                <a href="#">Buy Sall Rent</a>
                            </div>
                            <div class="heading-title">
                                
                                <h2>Shree Ran Properties & Construction</h2>
                            </div>
                              <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Architecto, soluta ipsa vel, eveniet fuga nulla accusantium explicabo excepturi blanditiis et nobis ex quas iste reprehenderit ratione iure dolores, dolore aperiam recusandae at aspernatur. Ut repudiandae quae deserunt cum optio suscipit, reprehenderit laboriosam excepturi nesciunt</p>
                            <div class="price-area-style-1">
                                <div class="details-button">
                                    <a href="contact-us.php" class="item-btn">Contact Us</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-6">
                        <div class="featured-thumb-slider-area">
                            <div class="inner-box-1">
                                <div class="feature-box2 swiper-container wow fadeInRight" data-wow-delay=".3s">
                                    <div class="swiper-wrapper">
                                        <div class="swiper-slide">
                                            <div class="feature-img1">
                                                <img src="img/img-4.jpg" alt="" >
                                            </div>
                                        </div>
                                        <div class="swiper-slide">
                                            <div class="feature-img1">
                                                <img src="img/img-5.jpg" alt="">
                                            </div>
                                        </div>
    
                                        <div class="swiper-slide">
                                            <div class="feature-img1">
                                                <img src="img/img-6.jpg" alt="">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="inner-box-2">
                                    <div class="featured-thum-slider swiper-container">
                                        <div class="swiper-wrapper">
                                            <div class="swiper-slide">
                                                <div class="item-img">
                                                    <img src="img/img-4.jpg" alt="" >
                                                </div>
                                            </div>
                                            <div class="swiper-slide">
                                                <div class="item-img">
                                                    <img src="img/img-5.jpg" alt="" >
                                                </div>
                                            </div>
                                            <div class="swiper-slide">
                                                <div class="item-img">
                                                    <img src="img/img-6.jpg" alt="">
                                                </div>
                                            </div>    
                                        </div>
                                    </div>
    
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>



<section class="about-wrap2 offdark-bg"style="background-color: #1e79b3;">
            <div class="container">
			  <div class="item-heading-center">      
                 <h2 class="section-title">Construction Update</h2>  <br>
             </div>
                <div class="row align-items-center">       
                    <div class="col-lg-12 col-12">
                        <div class="row">
                    <div class="col-lg-4 col-md-6 col-6">
                        <div class="team-box1 team-box2 wow fadeInUp" data-wow-delay=".6s">
                            <div class="item-img">
                                <a href="#">
                                    <img src="img/img-8.jpg" alt="">
                                </a>                           
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-6">
                        <div class="team-box1 team-box2 wow fadeInUp" data-wow-delay=".6s">
                            <div class="item-img">
                                <a href="#">
                                    <img src="img/img-9.jpg" alt="">
                                </a>                           
                            </div>
                        </div>
                    </div>
					<div class="col-lg-4 col-md-6 col-6">
                        <div class="team-box1 team-box2 wow fadeInUp" data-wow-delay=".6s">
                            <div class="item-img">
                                <a href="#">
                                    <img src="img/img-10.jpg" alt="">
                                </a>                           
                            </div>
                        </div>
                    </div>
					
                  </div>
                </div>
            </div>
        </section>
<!--=====================================-->

<?php include("inc/footer.php"); ?>
</body>
</html>


