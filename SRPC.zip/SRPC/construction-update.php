<!DOCTYPE html>
<html class="no-js" lang="en">
<head>
<meta charset="utf-8"/>
<title>Construction Update - Bhutani Cyberthum</title>
<meta name="description" content="">
<meta name="robots" content="INDEX, Follow" />
<meta name="language" content="en-us"/>
<meta name="revisit-after" content="2 days"/>
<link rel="canonical" href="#" />   
<?php include("inc/header.php"); ?>
<body class="sticky-header">
<?php include("inc/menu.php"); ?>
<!--=====================================-->
        <section class="about-wrap2 offdark-bg"style="background-color: #f6f6f6;">
            <div class="container">
			  <div class="item-heading-center">      
                 <h2 class="section-title">Construction-Update</h2>  
             </div>
                <div class="row align-items-center">       
                    <div class="col-lg-12 col-12">
                        <div class="row">
                    <div class="col-lg-4 col-md-6 col-6">
                        <div class="team-box1 team-box2 wow fadeInUp" data-wow-delay=".6s">
                            <div class="item-img">
                                <a href="#">
                                    <img src="img/construction-update-2.jpg" alt="">
                                </a>                           
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-6">
                        <div class="team-box1 team-box2 wow fadeInUp" data-wow-delay=".6s">
                            <div class="item-img">
                                <a href="#">
                                    <img src="img/construction-update-3.jpg" alt="">
                                </a>                           
                            </div>
                        </div>
                    </div>
					<div class="col-lg-4 col-md-6 col-6">
                        <div class="team-box1 team-box2 wow fadeInUp" data-wow-delay=".6s">
                            <div class="item-img">
                                <a href="#">
                                    <img src="img/construction-update-4.jpg" alt="">
                                </a>                           
                            </div>
                        </div>
                    </div>
					<div class="col-lg-4 col-md-6 col-6">
                        <div class="team-box1 team-box2 wow fadeInUp" data-wow-delay=".6s">
                            <div class="item-img">
                                <a href="#">
                                    <img src="img/construction-update-5.jpg" alt="">
                                </a>                                                         
                            </div>
                        </div>
                    </div>
					<div class="col-lg-4 col-md-6 col-6">
                        <div class="team-box1 team-box2 wow fadeInUp" data-wow-delay=".6s">
                            <div class="item-img">
                                <a href="#">
                                    <img src="img/construction-update-6.jpg" alt="">
                                </a>                                                         
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-6">
                        <div class="team-box1 team-box2 wow fadeInUp" data-wow-delay=".6s">
                            <div class="item-img">
                                <a href="#">
                                    <img src="img/construction-update-7.jpg" alt="">
                                </a>                                                         
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-6">
                        <div class="team-box1 team-box2 wow fadeInUp" data-wow-delay=".6s">
                            <div class="item-img">
                                <a href="#">
                                    <img src="img/construction-update-8.jpg" alt="">
                                </a>                                                         
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-6">
                        <div class="team-box1 team-box2 wow fadeInUp" data-wow-delay=".6s">
                            <div class="item-img">
                                <a href="#">
                                    <img src="img/construction-update-9.jpg" alt="">
                                 </a>                                                         
                              </div>
                           </div>
                        </div>
                        <div class="col-lg-4 col-md-6 col-6">
                        <div class="team-box1 team-box2 wow fadeInUp" data-wow-delay=".6s">
                            <div class="item-img">
                                <a href="#">
                                    <img src="img/construction-update-10.jpg" alt="">
                                </a>                                                         
                            </div>
                        </div>
                      </div> 
                    </div>
                  </div>
                </div>
            </div>
        </section>
<!--=====================================-->
<?php include("inc/footer.php"); ?>
</body>
</html>
	
	
	
	
      

	
	
	

	  
	  
	  
	