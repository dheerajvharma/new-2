
      <header class="rt-header sticky-on">
        <div id="sticky-placeholder"></div>
        <div id="navbar-wrap" class="header-menu menu-layout1 header-menu menu-layout2">
          <div class="container">
            <div class="row d-flex align-items-center">
              <div class="col-xl-2 col-lg-2">
                <div class="logo-area">
                  <a href="index.php" class="temp-logo">
                    <img src="img/logo.jpeg"width="65" alt=""class="img-fluid"/>
                  </a>
                </div>
              </div>
              <div class=" col-xl-8 col-lg-8 d-flex justify-content-center position-static">
                <nav id="dropdown"class="template-main-menu template-main-menu-3">
                  <ul>
                     <li><a href="index.php">Home</a></li>
                     <li><a href="about-us.php">About Us</a></li>
                     <li><a href="services.php">Buy Sall Rent</a></li>
					           <li><a href="contact-us.php">Contact Us</a></li>
                  </ul>
                </nav>
              </div>
             <div class="col-xl-2 col-lg-2 d-flex justify-content-end">
                <div class="header-action-layout1">
                  <ul class="action-list">
                     <li class="listing-button">
                        <a href="tel: 09896707022" class="listing-btn">
                            <span><i class="fas fa-phone-alt"></i></span>
                            <span> 09896707022</span>
                        </a>
                    </li> 
                  </ul>
                </div>
              </div> 
            </div>
          </div>
        </div>
      </header>
      <div class="rt-header-menu mean-container position-relative"id="meanmenu">
        <div class="mean-bar">
          <a href="index.php">
            <img src="img/logo.jpeg" width="65" alt=" " class="img-fluid"/></a>
          <div class="mean-bar--right">
            <div class="actions search">
            </div>
            <div class="actions user">
            </div>
            <span class="sidebarBtn">
              <span class="bar"></span>
              <span class="bar"></span>
              <span class="bar"></span>
              <span class="bar"></span>
            </span>
          </div>
        </div>
        <div class="rt-slide-nav"> 
          <div class="offscreen-navigation"> 
            <nav class="menu-main-primary-container"> 
              <ul class="menu"> 
                  <li><a href="index.php">Home</a></li>
                  <li><a href="about-us.php">About Us</a></li>
                  <li><a href="services.php">Buy Sall Rent</a></li>
				          <li><a href="contact-us.php">Contact Us</a></li>
				          <li><a href="tel: 098967 07022"><i class="fas fa-phone-alt"></i> Call Us: 9896707022</a></li>
             </nav>
           </div>
         </div>
       </div>
