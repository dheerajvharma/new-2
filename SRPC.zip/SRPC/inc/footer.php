<div class="fixed-icons">
<!-- WhatsApp Icon -->
  <a href="https://wa.me/+91 9896707022" target="_blank" rel="noopener" class="whatsapp">
    <i class="fab fa-whatsapp"></i>
  </a>
<!-- Call Icon -->
  <a href="tel: 09896707022" class="call">
    <i class="fas fa-phone-alt"></i>
  </a>
<!-- Email Icon -->
  <a href="#" data-bs-toggle="modal" data-bs-target="#contactModal" class="email">
    <i class="fas fa-envelope"></i>
  </a>
</div>
<!--==========================-->
<div class="modal fade" id="contactModal" tabindex="-1" aria-labelledby="contactModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <?php include("inc/form.php"); ?>
        </div>
      </div>
    </div>
  </div>
</div>
<!--==========================-->
         <footer class="footer-area">
            <div class="footer-top footer-top-style">
                <div class="container">
                    <div class="row justify-content-between">
                        <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                            <div class="footer-logo-area footer-logo-area-2">
                                <div class="item-logo">
                                    <img src="img/logo.jpeg" width="100" height="100" alt="" class="img-fluid" style="border-radius: 10px;">
                                </div>
                                <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Praesentium tempore tempora ipsam. </p>
                                <div class="item-social">
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-2 col-lg-2 col-md-6 col-sm-6">
                            <div class="footer-link footer-link-style-2">
                                <div class="footer-title footer-title-style2">
                                    <h3>Quick Links</h3>
                                </div>
                                <div class="item-link">
                                    <ul>
                                      <li><a href="index.php">Home</a></li>
                                      <li><a href="about-us.php">About Us</a></li>
                                      <li><a href="services.php">Buy Sall Rent</a></li>
					                            <li><a href="contact-us.php">Contact Us</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                       
                        <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
                            <div class="footer-contact footer-contact-style-2">
                                <div class="footer-title footer-title-style2">
                                    <h3>Contact</h3>
                                </div>
                                <div class="footer-location">
                                    <ul>
                                        <li class="item-map"><i class="fas fa-map-marker-alt"></i>  Shop No. B 14 Main Market Sector-1 IMT Manesar, Gurugram (Hr.) 122052</li>
                                        <li><a href="tel: 09896707022"><i class="fas fa-phone-alt"></i> 9896707022</a></li>
                                        <li><a href="tel: 09896707044"><i class="fas fa-phone-alt"></i> 989670704</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="footer-bottom footer-bottom-style-2">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg-6 col-md-6">
                             <p>© 2023 Shree Ran Properties & Construction</p>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
           <a href="javascript:void(0)" id="back-to-top">
        <i class="fas fa-angle-double-up"></i>
      </a>
    </div>
    <div id="template-search" class="template-search">
      <button type="button" class="close">×</button>
      <form class="search-form">
        <input type="search" value="" placeholder="Search" />
        <button type="submit" class="search-btn btn-ghost style-1">
          <i class="flaticon-search"></i>
        </button>
      </form>
    </div>
    <script src="js/jquery-3.6.0.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="vendor/owlcarousel/owl.carousel.min.js"></script>
    <script src="js/swiper-bundle.min.js"></script>
    <script src="js/jquery.appear.min.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/parallaxie.js"></script>
    <script src="js/tween-max.js"></script>
    <script src="js/appear.min.js"></script>
    <script src="js/isotope.pkgd.min.js"></script>
    <script src="js/imagesloaded.pkgd.min.js"></script>
    <script src="vendor/noUiSlider/nouislider.min.js"></script>
    <script src="vendor/noUiSlider/wNumb.js"></script>
    <script src="js/validator.min.js"></script>
    <script src="js/pannellum.js"></script>
    <script src="js/jquery.zoom.min.js"></script>
    <script src="js/main.js"></script>
    <script src="js/functions.js"></script>
    </script>
    <script type="text/javascript" id="hs-script-loader" async defer src="//js.hs-scripts.com/9426686.js"></script>
</body>
</html>
